import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import * as express from 'express';
import { join } from 'path';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Enable CORS for your React frontend
  app.enableCors({
    origin: 'http://localhost:5173', // React app URL
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });

  // Enable class-validator globally
  app.useGlobalPipes(new ValidationPipe());

  // Serve static uploads folder
  app.use('/uploads', express.static(join(process.cwd(), 'uploads')));

  // Start server
  await app.listen(3000);
  console.log(`🚀 Server running on http://localhost:3000`);
  console.log(`📂 Uploads accessible at http://localhost:3000/uploads`);
}
bootstrap();
