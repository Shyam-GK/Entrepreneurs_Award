import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  StreamableFile,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like as TypeormLike } from 'typeorm';
import { NomineeDetails } from './entities/nominee-details.entity';
import { Award } from './entities/award.entity';
import { Ipr } from './entities/ipr.entity';
import { Merger } from './entities/merger.entity';
import { Collaboration } from './entities/collaboration.entity';
import { UpdateNomineeDetailsDto } from './dto/update-nominee-details.dto';
import { CreateAwardDto } from './dto/create-award.dto';
import { CreateIprDto } from './dto/create-ipr.dto';
import { CreateMergerDto } from './dto/create-merger.dto';
import { CreateCollaborationDto } from './dto/create-collaboration.dto';
import * as fs from 'fs';
import * as path from 'path';
import { NominationsService } from '../nominations/nominations.service';
import { Express } from 'express';

@Injectable()
export class NomineeDetailsService {
  constructor(
    @InjectRepository(NomineeDetails) private nomineeRepo: Repository<NomineeDetails>,
    @InjectRepository(Award) private awardRepo: Repository<Award>,
    @InjectRepository(Ipr) private iprRepo: Repository<Ipr>,
    @InjectRepository(Merger) private mergerRepo: Repository<Merger>,
    @InjectRepository(Collaboration) private collabRepo: Repository<Collaboration>,
    private nominationsService: NominationsService,
  ) {}

  private async findNomineeOwnedByUser(nomineeId: string, userId: string): Promise<NomineeDetails> {
    const nominee = await this.nomineeRepo.findOne({
      where: { id: nomineeId },
      relations: ['user'],
    });
    if (!nominee) throw new NotFoundException('Nominee not found');
    if (nominee.user.id !== userId) throw new ForbiddenException('Not authorized');
    return nominee;
  }

  async updateProfile(nomineeId: string, userId: string, dto: UpdateNomineeDetailsDto) {
    const nominee = await this.findNomineeOwnedByUser(nomineeId, userId);
    Object.assign(nominee, dto);
    return this.nomineeRepo.save(nominee);
  }

  async uploadFile(id: string, userId: string, type: string, file?: Express.Multer.File) {
    const nominee = await this.findNomineeOwnedByUser(id, userId);
    if (!file) throw new HttpException('No file uploaded', HttpStatus.BAD_REQUEST);

    const relPath = path.join('uploads', type, id, file.filename);

    if (type === 'photo') nominee.photo = relPath;
    else if (type === 'registration') nominee.registrationCertificate = relPath;
    else throw new HttpException('Use specific endpoint for structured uploads', HttpStatus.BAD_REQUEST);

    await this.nomineeRepo.save(nominee);
    await this.nominationsService.updateNominationStatus(nominee.user.email, nominee.user.id);

    return { filePath: relPath };
  }

  async addAward(nomineeId: string, userId: string, dto: CreateAwardDto, file: Express.Multer.File) {
    const nominee = await this.findNomineeOwnedByUser(nomineeId, userId);
    if (!file) throw new HttpException('File required for award', HttpStatus.BAD_REQUEST);

    const relPath = path.join('uploads', 'award', nomineeId, file.filename);
    const award = this.awardRepo.create({ ...dto, nominee, filePath: relPath });

    nominee.hasAwards = true;
    await this.nomineeRepo.save(nominee);
    await this.nominationsService.updateNominationStatus(nominee.user.email, nominee.user.id);

    return this.awardRepo.save(award);
  }

  async addIpr(nomineeId: string, userId: string, dto: CreateIprDto, file: Express.Multer.File) {
    const nominee = await this.findNomineeOwnedByUser(nomineeId, userId);
    const ipr = this.iprRepo.create({
      ...dto,
      nominee,
      filePath: `uploads/ipr/${nomineeId}/${file.filename}`,
    });
    return this.iprRepo.save(ipr);
  }

  async addMerger(nomineeId: string, userId: string, dto: CreateMergerDto, file: Express.Multer.File) {
    const nominee = await this.findNomineeOwnedByUser(nomineeId, userId);
    const merger = this.mergerRepo.create({
      ...dto,
      nominee,
      filePath: `uploads/merger/${nomineeId}/${file.filename}`,
    });
    return this.mergerRepo.save(merger);
  }

  async addCollaboration(nomineeId: string, userId: string, dto: CreateCollaborationDto, file: Express.Multer.File) {
    const nominee = await this.findNomineeOwnedByUser(nomineeId, userId);
    const collab = this.collabRepo.create({
      ...dto,
      nominee,
      filePath: `uploads/academic_collab/${nomineeId}/${file.filename}`,
    });
    return this.collabRepo.save(collab);
  }

  async getFile(fileId: string): Promise<StreamableFile> {
    const searchPattern = TypeormLike(`%${fileId}%`);

    const nd = await this.nomineeRepo.findOne({
      where: [{ photo: searchPattern }, { registrationCertificate: searchPattern }],
    });
    if (nd) {
      const filePath = nd.photo?.includes(fileId) ? nd.photo : nd.registrationCertificate;
      if (filePath && fs.existsSync(filePath)) {
        return new StreamableFile(fs.createReadStream(filePath));
      }
    }

    const repos = [this.awardRepo, this.iprRepo, this.mergerRepo, this.collabRepo];
    for (const repo of repos) {
      const rec = await repo.findOne({ where: { filePath: searchPattern } });
      if (rec?.filePath && fs.existsSync(rec.filePath)) {
        return new StreamableFile(fs.createReadStream(rec.filePath));
      }
    }

    throw new HttpException('File not found', HttpStatus.NOT_FOUND);
  }
}
