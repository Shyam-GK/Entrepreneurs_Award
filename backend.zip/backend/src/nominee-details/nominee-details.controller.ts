// X:\Projects\Entrepreneur\entrepreneur-award\src\nominee-details\nominee-details.controller.ts
import { Controller, Post, Body, Param, UseGuards, Request, UseInterceptors, UploadedFile, Get } from '@nestjs/common';
import { NomineeDetailsService } from './nominee-details.service';
import { UpdateNomineeDetailsDto } from './dto/update-nominee-details.dto';
import { CreateAwardDto } from './dto/create-award.dto';
import { CreateIprDto } from './dto/create-ipr.dto';
import { CreateMergerDto } from './dto/create-merger.dto';
import { CreateCollaborationDto } from './dto/create-collaboration.dto';
import { AuthGuard } from '@nestjs/passport';
import { FileInterceptor } from '@nestjs/platform-express';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
// import * as Multer from 'multer'; // Not needed for type

@Controller('nominee-details')
export class NomineeDetailsController {
  constructor(private readonly nomineeDetailsService: NomineeDetailsService) {}

  @Post(':id/profile')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  async updateProfile(@Param('id') id: string, @Body() updateNomineeDetailsDto: UpdateNomineeDetailsDto, @Request() req) {
    return this.nomineeDetailsService.updateProfile(id, req.user.id, updateNomineeDetailsDto);
  }

  @Post(':id/upload/:type')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@Param('id') id: string, @Param('type') type: string, @UploadedFile() file: Express.Multer.File, @Request() req) {
    return this.nomineeDetailsService.uploadFile(id, req.user.id, type, file);
  }

  @Post(':id/awards')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  @UseInterceptors(FileInterceptor('file'))
  async addAward(@Param('id') id: string, @Body() createAwardDto: CreateAwardDto, @UploadedFile() file: Express.Multer.File, @Request() req) {
    return this.nomineeDetailsService.addAward(id, req.user.id, createAwardDto, file);
  }

  @Post(':id/iprs')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  @UseInterceptors(FileInterceptor('file'))
  async addIpr(@Param('id') id: string, @Body() createIprDto: CreateIprDto, @UploadedFile() file: Express.Multer.File, @Request() req) {
    return this.nomineeDetailsService.addIpr(id, req.user.id, createIprDto, file);
  }

  @Post(':id/mergers')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  @UseInterceptors(FileInterceptor('file'))
  async addMerger(@Param('id') id: string, @Body() createMergerDto: CreateMergerDto, @UploadedFile() file: Express.Multer.File, @Request() req) {
    return this.nomineeDetailsService.addMerger(id, req.user.id, createMergerDto, file);
  }

  @Post(':id/collaborations')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @Roles('user')
  @UseInterceptors(FileInterceptor('file'))
  async addCollaboration(@Param('id') id: string, @Body() createCollaborationDto: CreateCollaborationDto, @UploadedFile() file: Express.Multer.File, @Request() req) {
    return this.nomineeDetailsService.addCollaboration(id, req.user.id, createCollaborationDto, file);
  }

  @Get('uploads/:fileId')
  async getFile(@Param('fileId') fileId: string) {
    return this.nomineeDetailsService.getFile(fileId);
  }
}