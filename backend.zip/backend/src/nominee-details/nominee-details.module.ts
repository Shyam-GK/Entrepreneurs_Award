import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NomineeDetailsService } from './nominee-details.service';
import { NomineeDetailsController } from './nominee-details.controller';
import { NomineeDetails } from './entities/nominee-details.entity';
import { Award } from './entities/award.entity';
import { Ipr } from './entities/ipr.entity';
import { Merger } from './entities/merger.entity';
import { Collaboration } from './entities/collaboration.entity';
import { UsersModule } from '../users/users.module';
import { NominationsModule } from '../nominations/nominations.module';
import { MulterModule } from '@nestjs/platform-express';
import { createMulterStorage, uploadFileFilter } from '../common/upload.storage';
  
@Module({
  imports: [
    TypeOrmModule.forFeature([NomineeDetails, Award, Ipr, Merger, Collaboration]),
    UsersModule,
    forwardRef(() => NominationsModule),
    MulterModule.register({
      storage: createMulterStorage(),
      fileFilter: uploadFileFilter,
      limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
    }),
  ],  
  providers: [NomineeDetailsService],
  controllers: [NomineeDetailsController],
  exports: [NomineeDetailsService],
})
export class NomineeDetailsModule {}
