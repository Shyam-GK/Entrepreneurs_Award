export class CreateNomineeDetailDto {}
