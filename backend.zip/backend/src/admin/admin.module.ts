// X:\Projects\Entrepreneur\entrepreneur-award\src\admin\admin.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { Nomination } from '../nominations/entities/nomination.entity';
import { NomineeDetails } from '../nominee-details/entities/nominee-details.entity';
import { Award } from '../nominee-details/entities/award.entity';
import { Ipr } from '../nominee-details/entities/ipr.entity';
import { Merger } from '../nominee-details/entities/merger.entity';
import { Collaboration } from '../nominee-details/entities/collaboration.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Nomination, NomineeDetails, Award, Ipr, Merger, Collaboration])],
  providers: [AdminService],
  controllers: [AdminController],
})
export class AdminModule {}