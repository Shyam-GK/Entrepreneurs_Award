// X:\Projects\Entrepreneur\entrepreneur-award\src\admin\admin.controller.ts
import { Controller, Get, Post, Param, Query, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@Controller('admin')
@UseGuards(AuthGuard('jwt'), RolesGuard)
@Roles('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('nominations')
  async getAllNominations(@Query('status') status?: string) {
    return this.adminService.getAllNominations(status);
  }

  @Get('nominee-details/:id')
  async getNomineeDetails(@Param('id') id: string) {
    return this.adminService.getNomineeDetails(id);
  }

  @Get('nominee-details/:id/files')
  async getNomineeFiles(@Param('id') id: string) {
    return this.adminService.getNomineeFiles(id);
  }

  @Post('nominee-details/:id/approve')
  async approveNominee(@Param('id') id: string) {
    return this.adminService.approveNominee(id);
  }

  @Post('nominee-details/:id/reject')
  async rejectNominee(@Param('id') id: string) {
    return this.adminService.rejectNominee(id);
  }
}