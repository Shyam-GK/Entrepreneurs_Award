import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { Nomination } from '../nominations/entities/nomination.entity';
import { NomineeDetails } from '../nominee-details/entities/nominee-details.entity';
import { Award } from '../nominee-details/entities/award.entity';
import { Ipr } from '../nominee-details/entities/ipr.entity';
import { Merger } from '../nominee-details/entities/merger.entity';
import { Collaboration } from '../nominee-details/entities/collaboration.entity';
import { NominationStatus } from '../enums/enums';

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(Nomination)
    private nominationRepository: Repository<Nomination>,
    @InjectRepository(NomineeDetails)
    private nomineeDetailsRepository: Repository<NomineeDetails>,
    @InjectRepository(Award)
    private awardRepository: Repository<Award>,
    @InjectRepository(Ipr)
    private iprRepository: Repository<Ipr>,
    @InjectRepository(Merger)
    private mergerRepository: Repository<Merger>,
    @InjectRepository(Collaboration)
    private collaborationRepository: Repository<Collaboration>,
  ) {}

  async getAllNominations(status?: string): Promise<Nomination[]> {
    const where = status ? { status: status as NominationStatus } : {};
    return this.nominationRepository.find({
      where,
      relations: ['nominator', 'nomineeUser'],
      order: { nominatedAt: 'DESC' },
    });
  }

  async getNomineeDetails(id: string): Promise<NomineeDetails> {
    const nomineeDetails = await this.nomineeDetailsRepository.findOne({
      where: { id },
      relations: ['user', 'awards', 'iprs', 'mergers', 'collaborations'],
    });
    if (!nomineeDetails) {
      throw new HttpException('Nominee details not found', HttpStatus.NOT_FOUND);
    }
    return nomineeDetails;
  }

  async getNomineeFiles(id: string): Promise<string[]> {
    const nomineeDetails = await this.nomineeDetailsRepository.findOne({
      where: { id },
      relations: ['awards', 'iprs', 'mergers', 'collaborations'],
    });
    if (!nomineeDetails) {
      throw new HttpException('Nominee details not found', HttpStatus.NOT_FOUND);
    }

    const files: string[] = [];
    if (nomineeDetails.photo) files.push(nomineeDetails.photo);
    if (nomineeDetails.registrationCertificate) files.push(nomineeDetails.registrationCertificate);

    const awards = await this.awardRepository.find({ where: { nominee: { id } } });
    awards.forEach(award => award.filePath && files.push(award.filePath));

    const iprs = await this.iprRepository.find({ where: { nominee: { id } } });
    iprs.forEach(ipr => ipr.filePath && files.push(ipr.filePath));

    const mergers = await this.mergerRepository.find({ where: { nominee: { id } } });
    mergers.forEach(merger => merger.filePath && files.push(merger.filePath));

    const collaborations = await this.collaborationRepository.find({ where: { nominee: { id } } });
    collaborations.forEach(collaboration => collaboration.filePath && files.push(collaboration.filePath));

    return files.filter(file => file !== null);
  }

  async approveNominee(id: string): Promise<{ message: string }> {
    const nomineeDetails = await this.nomineeDetailsRepository.findOne({
      where: { id },
      relations: ['user'],
    });
    if (!nomineeDetails) {
      throw new HttpException('Nominee details not found', HttpStatus.NOT_FOUND);
    }
    await this.nominationRepository.update(
      { nomineeUser: { id: nomineeDetails.user.id }, status: NominationStatus.Submitted },
      { status: NominationStatus.Approved },
    );
    return { message: 'Nominee approved successfully' };
  }

  async rejectNominee(id: string): Promise<{ message: string }> {
    const nomineeDetails = await this.nomineeDetailsRepository.findOne({
      where: { id },  
      relations: ['user'],
    });
    if (!nomineeDetails) {
      throw new HttpException('Nominee details not found', HttpStatus.NOT_FOUND);
    }
    await this.nominationRepository.update(
      { nomineeUser: { id: nomineeDetails.user.id }, status: NominationStatus.Submitted },
      { status: NominationStatus.Rejected },    
    );
    return { message: 'Nominee rejected successfully' };
  }
}
